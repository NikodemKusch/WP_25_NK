package org.example;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class App extends JFrame implements ActionListener{
    private JTextField screen;
    private JTextField display;
    private MyGraphicsView screenGr;
    private JButton button_1 = new JButton("1");
    private JButton button_2 = new JButton("2");
    private JButton button_3 = new JButton("3");
    private JButton button_4 = new JButton("4");
    private JButton button_5 = new JButton("5");
    private JButton button_6 = new JButton("6");
    private JButton button_7 = new JButton("7");
    private JButton button_8 = new JButton("8");
    private JButton button_9 = new JButton("9");
    private JButton button_0 = new JButton("0");
    private JButton button_add = new JButton("+");
    private JButton button_substract = new JButton("-");
    private JButton button_divide = new JButton("/");
    private JButton button_multiply = new JButton("*");
    private JButton button_equal = new JButton("=");
    private JButton button_C = new JButton("C");
    private JButton button_backspace = new JButton("<-");
    private String text = "";

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof JButton) {
            String digit = ((JButton) source).getText();
            text += digit;
            display.setText(text);
            screenGr.setTex(text);
        }
    }

    public App() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel displayPanel = new JPanel(new BorderLayout());
        displayPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        display = new JTextField(10);
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setFont(new Font("Arial", Font.BOLD, 24));

        displayPanel.add(display, BorderLayout.CENTER);

        screenGr = new MyGraphicsView();
        screenGr.setPreferredSize(new Dimension(200,50));
        panel.add("North", displayPanel);
        panel.add("South",screenGr);
        JPanel panelButtons = new JPanel(new GridLayout(5, 4));

        button_9.addActionListener(this);
        panelButtons.add(button_9);

        button_8.addActionListener(this);
        panelButtons.add(button_8);

        button_7.addActionListener(this);
        panelButtons.add(button_7);

        button_divide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!text.equals("") && !text.contains(" ")){
                    text += " / ";
                    display.setText(text);
                    screenGr.setTex(text);
                }
            }

        });
        panelButtons.add(button_divide);

        button_6.addActionListener(this);
        panelButtons.add(button_6);

        button_5.addActionListener(this);
        panelButtons.add(button_5);

        button_4.addActionListener(this);
        panelButtons.add(button_4);

        button_multiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!text.equals("") && !text.contains(" ")){
                    text += " * ";
                    display.setText(text);
                    screenGr.setTex(text);
                }
            }
        });
        panelButtons.add(button_multiply);

        button_3.addActionListener(this);
        panelButtons.add(button_3);

        button_2.addActionListener(this);
        panelButtons.add(button_2);

        button_1.addActionListener(this);
        panelButtons.add(button_1);

        button_substract.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!text.equals("") && !text.contains(" ")){
                    text += " - ";
                    display.setText(text);
                    screenGr.setTex(text);
                }
            }
        });
        panelButtons.add(button_substract);

        button_C.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                text = "";
                display.setText("");
                screenGr.setTex("");
            }
        });
        panelButtons.add(button_C);

        button_0.addActionListener(this);
        panelButtons.add(button_0);

        button_backspace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (text.length() > 0) {
                    text = text.substring(0, text.length() - 1);
                    display.setText(text);
                    screenGr.setTex(text);
                }
            }
        });
        panelButtons.add(button_backspace);

        button_add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!text.equals("") && !text.contains(" ")){
                    text += " + ";
                    display.setText(text);
                    screenGr.setTex(text);
                }
            }
        });
        panelButtons.add(button_add);
        panelButtons.add(new JLabel());
        panelButtons.add(new JLabel());
        panelButtons.add(new JLabel());

        button_equal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String expression = text.trim();
                    if (expression.contains(" ")) {
                        String[] parts = expression.split(" ");
                        if (parts.length == 3) {
                            double num1 = Double.parseDouble(parts[0]);
                            String op = parts[1];
                            double num2 = Double.parseDouble(parts[2]);
                            double result = 0;
                            switch (op) {
                                case "+":
                                    result = num1 + num2;
                                    break;
                                case "-":
                                    result = num1 - num2;
                                    break;
                                case "*":
                                    result = num1 * num2;
                                    break;
                                case "/":
                                    if (num2 != 0) {
                                        result = num1 / num2;
                                    } else {
                                        display.setText("Error: Division by zero");
                                        screenGr.setTex("Error: Division by zero");
                                        return;
                                    }
                                    break;
                                default:
                                    display.setText("Error: Invalid operation");
                                    screenGr.setTex("Error: Invalid operation");
                                    return;
                            }
                            String resultStr = String.format("%.2f", result);
                            text = resultStr;
                            display.setText(resultStr);
                            screenGr.setTex(resultStr);
                        } else {
                            display.setText("Error: Invalid expression");
                            screenGr.setTex("Error: Invalid expression");
                        }
                    } else {
                        display.setText("Error: No operation");
                        screenGr.setTex("Error: No operation");
                    }
                } catch (NumberFormatException ex) {
                    display.setText("Error: Invalid number");
                    screenGr.setTex("Error: Invalid number");
                }
            }
        });
        panelButtons.add(button_equal);

        panel.add("Center", panelButtons);
        setContentPane(panel);
        pack();
        setVisible(true);
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new App();
            }
        });

    }

}