package org.example;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class App extends JFrame {
    private JTextField screen;
    private JButton button_1 = new JButton("1");
    private JButton button_2 = new JButton("2");
    private JButton button_3 = new JButton("3");
    private JButton button_4 = new JButton("4");
    private JButton button_5 = new JButton("5");
    private JButton button_6 = new JButton("6");
    private JButton button_7 = new JButton("7");
    private JButton button_8 = new JButton("8");
    private JButton button_9 = new JButton("9");
    private JButton button_0 = new JButton("0");
    private JButton button_add = new JButton("+");
    private JButton button_substract = new JButton("-");
    private JButton button_divide = new JButton("/");
    private JButton button_multiply = new JButton("*");
    private JButton button_equal = new JButton("=");
    private JButton button_C = new JButton("C");
    private JButton button_backspace = new JButton("<-");

    private double result;

    public App() {
        JPanel panel = new JPanel(new BorderLayout());
        screen = new JTextField(10);
        panel.add("North", screen);
        JPanel panelButtons = new JPanel(new GridLayout(5, 4));

        button_9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                screen.setText( screen.getText() + "9");
            }

        });
        panelButtons.add(button_9);

        button_8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "8");

            }
        });
        panelButtons.add(button_8);

        button_7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "7");

            }
        });
        panelButtons.add(button_7);

        button_divide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " / ");
                }
            }

        });
        panelButtons.add(button_divide);

        button_6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "6");

            }
        });
        panelButtons.add(button_6);

        button_5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "5");

            }
        });
        panelButtons.add(button_5);

        button_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "4");

            }
        });
        panelButtons.add(button_4);

        button_multiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " * ");
                }
            }
        });
        panelButtons.add(button_multiply);

        button_3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "3");

            }
        });
        panelButtons.add(button_3);

        button_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "2");

            }
        });
        panelButtons.add(button_2);

        button_1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "1");

            }
        });
        panelButtons.add(button_1);

        button_substract.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " - ");
                }
            }
        });
        panelButtons.add(button_substract);

        button_C.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                screen.setText("");
            }
        });
        panelButtons.add(button_C);

        button_0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "0");

            }
        });
        panelButtons.add(button_0);

        button_backspace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (text.length() > 0) {
                    screen.setText(text.substring(0, text.length() - 1));
                }
            }
        });
        panelButtons.add(button_backspace);

        button_add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " + ");
                }
            }
        });
        panelButtons.add(button_add);
        panelButtons.add(new JLabel());
        panelButtons.add(new JLabel());
        panelButtons.add(new JLabel());

        button_equal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                String[] parts = text.split("\\s+");
                if (parts.length == 3) {
                    double a = Double.parseDouble(parts[0]);
                    String op = parts[1];
                    double b = Double.parseDouble(parts[2]);
                    switch (op) {
                        case "+":
                            result = a + b;
                            break;
                        case "-":
                            result = a - b;
                            break;
                        case "*":
                            result = a * b;
                            break;
                        case "/":
                            if (b != 0) {
                                result = a / b;
                            } else {
                                screen.setText("Error");
                                return;
                            }
                            break;
                    }
                    screen.setText(String.valueOf(result));
                }
            }
        });
        panelButtons.add(button_equal);

        panel.add("Center", panelButtons);
        setContentPane(panel);
        pack();
        setVisible(true);
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new App();
            }
        });

    }

}