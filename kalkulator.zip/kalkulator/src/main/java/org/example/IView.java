package org.example;

public interface IView {
    void setTex(String data);
}
