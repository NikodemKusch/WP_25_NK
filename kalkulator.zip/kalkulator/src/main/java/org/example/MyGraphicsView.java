package org.example;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class MyGraphicsView extends JPanel implements IView{
    private String text = "";

    @Override
    public void setTex(String data){
        this.text = data;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.drawString(text,10,getHeight()/2);
    }
}
