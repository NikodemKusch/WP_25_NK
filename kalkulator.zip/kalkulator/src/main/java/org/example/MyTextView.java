package org.example;

import javax.swing.JTextField;

public class MyTextView extends JTextField implements IView {
    @Override
    public void setTex(String data) {
        setText(data);
    }
}
